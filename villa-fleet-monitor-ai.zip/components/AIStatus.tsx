import React, { useState } from 'react';
import { Unit } from '../types';
import { analyzeFleetStatus } from '../services/geminiService';
import { Sparkles, X, AlertOctagon, Bot } from 'lucide-react';

interface AIStatusProps {
  units: Unit[];
  routeName: string | null;
}

const AIStatus: React.FC<AIStatusProps> = ({ units, routeName }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ summary: string; alerts: string[] } | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleAnalyze = async () => {
    setIsOpen(true);
    setLoading(true);
    setResult(null);
    const data = await analyzeFleetStatus(units, routeName);
    setResult(data);
    setLoading(false);
  };

  if (!isOpen && !loading) {
    return (
      <button 
        onClick={handleAnalyze}
        className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white px-4 py-2 rounded-full shadow-lg shadow-purple-900/50 transition-all transform hover:scale-105 font-medium text-sm"
      >
        <Sparkles size={16} />
        <span>Analizar con IA</span>
      </button>
    );
  }

  return (
    <div className="relative w-full md:w-auto">
      <div className="bg-slate-800 border border-slate-600 rounded-xl p-4 shadow-2xl md:min-w-[350px] animate-in fade-in zoom-in duration-200">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2 text-purple-400">
            <Bot size={20} />
            <h3 className="font-bold text-white">Análisis de Flota Gemini</h3>
          </div>
          <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
            <X size={16} />
          </button>
        </div>

        {loading ? (
          <div className="py-4 flex flex-col items-center justify-center text-slate-400 gap-3">
            <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs animate-pulse">Analizando telemetría en tiempo real...</p>
          </div>
        ) : result ? (
          <div className="space-y-3">
            <p className="text-slate-300 text-sm leading-relaxed border-l-2 border-purple-500 pl-3">
              {result.summary}
            </p>
            {result.alerts.length > 0 && (
              <div className="mt-3">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Alertas Detectadas:</p>
                <ul className="space-y-1">
                  {result.alerts.map((alert, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-red-300 bg-red-900/20 p-2 rounded">
                      <AlertOctagon size={12} className="mt-0.5 shrink-0" />
                      {alert}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default AIStatus;