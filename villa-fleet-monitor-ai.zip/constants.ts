import { Unit, RouteName } from './types';

export const ROUTES: RouteName[] = ['RUTA W', 'RUTA B', 'RUTA G', 'RUTA 22'];

export const MOCK_UNITS: Unit[] = [
  // RUTA W
  {
    id: 'U-101',
    plate: '301-ARY780',
    route: 'RUTA W',
    lastReport: '26/11/2025 14:56',
    speed: 45,
    lat: -12.235332,
    lng: -77.235332,
    address: 'Av. Larco Herrera, Lima',
    status: 'moving'
  },
  {
    id: 'U-102',
    plate: '405-BGT990',
    route: 'RUTA W',
    lastReport: '26/11/2025 14:55',
    speed: 0,
    lat: -12.245112,
    lng: -77.215122,
    address: 'Calle Los Pinos 123, Villa',
    status: 'stopped'
  },
  // RUTA B
  {
    id: 'U-201',
    plate: '111-PLK234',
    route: 'RUTA B',
    lastReport: '26/11/2025 14:58',
    speed: 62,
    lat: -12.215332,
    lng: -77.255332,
    address: 'Panamericana Sur Km 15',
    status: 'moving'
  },
  {
    id: 'U-202',
    plate: '222-QWE456',
    route: 'RUTA B',
    lastReport: '26/11/2025 14:50',
    speed: 12,
    lat: -12.205332,
    lng: -77.265332,
    address: 'Av. El Sol 400',
    status: 'moving'
  },
  // RUTA G
  {
    id: 'U-301',
    plate: '777-XYZ888',
    route: 'RUTA G',
    lastReport: '26/11/2025 14:59',
    speed: 0,
    lat: -12.195332,
    lng: -77.275332,
    address: 'Estación Central',
    status: 'stopped'
  },
  // RUTA 22
  {
    id: 'U-401',
    plate: '999-MNB123',
    route: 'RUTA 22',
    lastReport: '26/11/2025 14:40',
    speed: 0,
    lat: -12.185332,
    lng: -77.285332,
    address: 'Taller Mecánico',
    status: 'offline'
  },
  {
    id: 'U-402',
    plate: '888-LKJ567',
    route: 'RUTA 22',
    lastReport: '26/11/2025 14:57',
    speed: 35,
    lat: -12.175332,
    lng: -77.295332,
    address: 'Av. Guardia Civil',
    status: 'moving'
  }
];