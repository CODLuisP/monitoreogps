import React, { useState, useMemo } from 'react';
import { MOCK_UNITS, ROUTES } from './constants';
import { RouteName } from './types';
import UnitTable from './components/UnitTable';
import RouteSelector from './components/RouteSelector';
import AIStatus from './components/AIStatus';
import { LayoutDashboard, Satellite } from 'lucide-react';

const App: React.FC = () => {
  // Use state to track selected route. Initially null (showing all, or could default to first)
  const [selectedRoute, setSelectedRoute] = useState<RouteName | null>('RUTA W');

  // Filter units based on selection
  const filteredUnits = useMemo(() => {
    if (!selectedRoute) return MOCK_UNITS;
    return MOCK_UNITS.filter(unit => unit.route === selectedRoute);
  }, [selectedRoute]);

  // Calculate counts for badges
  const routeCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    ROUTES.forEach(r => counts[r] = 0);
    MOCK_UNITS.forEach(u => {
      if (counts[u.route] !== undefined) counts[u.route]++;
    });
    return counts;
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 selection:bg-brand-500 selection:text-white pb-20">
      {/* Decorative Background Elements */}
      <div className="fixed top-0 left-0 w-full h-96 bg-gradient-to-b from-brand-900/20 to-transparent pointer-events-none -z-10" />
      <div className="fixed top-[-10%] right-[-5%] w-96 h-96 bg-blue-900/20 rounded-full blur-3xl pointer-events-none -z-10" />

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        
        {/* Header Section */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 border-b border-slate-800 pb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-brand-600 rounded-lg shadow-lg shadow-brand-900/50">
                <Satellite className="text-white" size={24} />
              </div>
              <h1 className="text-3xl font-black text-white tracking-tight">
                MONITOREO <span className="text-brand-500">VILLA</span>
              </h1>
            </div>
            <p className="text-slate-400 flex items-center gap-2">
              <LayoutDashboard size={16} />
              Panel de Control de Unidades en Tiempo Real
            </p>
          </div>
          
          <AIStatus units={filteredUnits} routeName={selectedRoute} />
        </header>

        {/* Route Selectors */}
        <section className="animate-in slide-in-from-bottom-4 duration-500">
          <RouteSelector 
            selectedRoute={selectedRoute} 
            onSelectRoute={setSelectedRoute} 
            counts={routeCounts}
          />
        </section>

        {/* Status Bar / Filter Info */}
        <div className="flex items-center justify-between mb-4 px-1">
          <h3 className="text-lg font-semibold text-white">
            {selectedRoute ? `Unidades de ${selectedRoute}` : 'Todas las Unidades'}
          </h3>
          <span className="text-xs font-mono text-slate-500 bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
            {filteredUnits.length} Resultados
          </span>
        </div>

        {/* Data Table */}
        <section className="animate-in slide-in-from-bottom-8 duration-700 delay-100">
          <UnitTable units={filteredUnits} />
        </section>

      </main>
    </div>
  );
};

export default App;